

const cliente = require('./rest_client.js');
const config = require('./resources/config');
const test = new cliente();

let results = [];
let data = {
  max: 0,
  min: 10000000,
  sum: 0,
  maxRequest: 0,
  minRequest: 10000000,
  sumRequest: 0,
  maxResponse: 0,
  minResponse: 10000000,
  sumResponse: 0
}
let  stopSending = false;
let timerId = setInterval(function () {   
    console.log("Sending...");
    test.TestLatency(results,data);
  }, 1000);

  setTimeout(function () {
    stopSending = true;
    clearInterval(timerId);     
    test.writeResults(results,data);
  }, config.sampleRunningTime);





