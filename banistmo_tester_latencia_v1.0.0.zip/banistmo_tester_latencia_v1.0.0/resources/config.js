﻿module.exports=
{
 
   "Service":{
      "Name":"Smartsoft_LatencyTest",
      "Description":"Aplicativo encargado de obtener la letencia de comunicación de un endponit",
      "Main":"app.js",
      "NodeOptions":"",
      "Start":false
   },
   
   "port":8089,
   "host":"http://20.110.222.99",
   "path":"/addTrans",
   "sampleQuantity":10,
   "sampleRunningTime":30000,
   "resultPath":"C:\\banistmo_tester_latencia_v1.0.0\\tester_latencia\\resultados\\"
}