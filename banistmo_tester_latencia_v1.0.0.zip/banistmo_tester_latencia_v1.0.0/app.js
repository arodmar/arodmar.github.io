global.appRoot = require('path').resolve(__dirname);
const config = require('./resources/config');

var express = require('express');
const bodyParser = require('body-parser');

var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(bodyParser.raw());

app.post(config.path, function (req, res) {
    try
    {
        const now = new Date() 
        let utcNow=now.getTime() + (now.getTimezoneOffset() * 60 * 1000) ;
        let receivedRequestTime = utcNow;
       // console.log("req.body.sendRequestTime:" +req.body.sendRequestTime);
      //  console.log("receivedRequestTime:" +receivedRequestTime);
        res.status(201).json({
            sendRequestTime: req.body.sendRequestTime,
            receivedRequestTime: receivedRequestTime,
            sendResponseTime: new Date().getTime() + (new Date().getTimezoneOffset() * 60 * 1000),
            });
    } catch (error) {
        res.status(500).json({
        message: "Failed to process request",
        });
       }
 })

var server = app.listen(config.port, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})


