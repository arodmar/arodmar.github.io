﻿

const config = require('./resources/config');
const fs = require('fs');
const converter = require('json-2-csv');

const superagent = require('superagent');
let rawdata = fs.readFileSync('./resources/transaction.json');
let transData = JSON.parse(rawdata);

class RestClient {

  async setData(rtResponse, data) {
    return new Promise((resolve) => {
      const now = new Date() 
      let utcNow=now.getTime() + (now.getTimezoneOffset() * 60 * 1000) ;
      let receivedResponseTime = utcNow;
      let responseJSON = JSON.parse(rtResponse.text);
      responseJSON.receivedResponseTime = receivedResponseTime;
      responseJSON.requestLatency = responseJSON.receivedRequestTime - responseJSON.sendRequestTime;
      responseJSON.responseLatency = responseJSON.receivedResponseTime - responseJSON.sendResponseTime;
      responseJSON.totalLatency = responseJSON.requestLatency + responseJSON.responseLatency;
      if (responseJSON.totalLatency > data.max)
        data.max = responseJSON.totalLatency;
      if (responseJSON.totalLatency < data.min)
        data.min = responseJSON.totalLatency;
      data.sum = data.sum + responseJSON.totalLatency;
  
      if (responseJSON.requestLatency > data.maxRequest)
        data.maxRequest = responseJSON.requestLatency;
      if (responseJSON.requestLatency < data.minRequest)
        data.minRequest = responseJSON.requestLatency;
      data.sumRequest = data.sumRequest + responseJSON.requestLatency;
  
      if (responseJSON.responseLatency > data.maxResponse)
        data.maxResponse = responseJSON.responseLatency;
      if (responseJSON.responseLatency < data.minResponse)
        data.minResponse = responseJSON.responseLatency;
      data.sumResponse = data.sumResponse + responseJSON.responseLatency;
  
      resolve(responseJSON);
    });
    
  }

  async TestLatency(results,data) {
          
    
    const now = new Date() 
    let utcNow=now.getTime() + (now.getTimezoneOffset() * 60 * 1000) ;
    transData.sendRequestTime = utcNow;
    const rtResponse = await superagent.post(
      config.host + ':' + config.port + config.path).send(transData);

    let cant = 0;   
    
    while ( cant < config.sampleQuantity) {        
      const now = new Date() 
      let utcNow=now.getTime() + (now.getTimezoneOffset() * 60 * 1000) ;    
        transData.sendRequestTime = utcNow;        
        try {       
          

            superagent.post(
              config.host + ':' + config.port + config.path).send(transData).then(rtResponse => {
                 this.setData(rtResponse, data).then(responseJSON => {
                results.push(responseJSON);
              })
              .catch(err => {
                 console.log(err.message);
              });
           })
           .catch(err => {
              console.log(err.message);
           });

        
        }
        catch (err) {
          console.log(err.message);
        }        
        cant += 1;   
      }
  }

  async writeResults(results,data){

    console.log("Latencia Total");
    console.log("Máximo:" + data.max);
    console.log("Mínimo:" + data.min);
    console.log("Promedio:" + data.sum / results.length);
    console.log();
    console.log("Latencia Request");
    console.log("Máximo:" + data.maxRequest);
    console.log("Mínimo:" + data.minRequest);
    console.log("Promedio:" + data.sumRequest / results.length);
    console.log();
    console.log("Latencia Response");
    console.log("Máximo:" + data.maxResponse);
    console.log("Mínimo:" + data.minResponse);
    console.log("Promedio:" + data.sumResponse / results.length);



    converter.json2csv(results, (err, csv) => {
      if (err) {
        console.log(err);
      }
      // write CSV to a file
      fs.writeFileSync(config.resultPath + 'latencyTestResults.csv', csv);
    });

    let statistics = "";
    statistics += "\nTotal de peticiones: " + results.length;
    statistics += "\nLatencia Total";
    statistics += "\nMáximo:" + data.max;
    statistics += "\nMínimo:" + data.min;
    statistics += "\nPromedio:" + data.sum / results.length;
    statistics += "\n";
    statistics += "\nLatencia Request";
    statistics += "\nMáximo:" + data.maxRequest;
    statistics += "\nMínimo:" + data.minRequest;
    statistics += "\nPromedio:" + data.sumRequest / results.length;
    statistics += "\n";
    statistics += "\nLatencia Response";
    statistics += "\nMáximo:" + data.maxResponse;
    statistics += "\nMínimo:" + data.minResponse;
    statistics += "\nPromedio:" + data.sumResponse / results.length;

    fs.writeFileSync(config.resultPath + 'latencyTestStatistics.txt', statistics);
    

  }
}

module.exports = RestClient;